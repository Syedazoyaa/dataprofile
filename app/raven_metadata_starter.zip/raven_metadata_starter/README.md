# Raven country metadata starter pack

This is an additive metadata package designed around Raven's existing `geography.py` / `geography_world.py` architecture. It is not a replacement for the current registry or generator.

## What is included

- `schemas/country_indicator.schema.json`: a schema for evidence-backed country indicators.
- `sources/source_registry.json`: suggested authoritative sources and the kinds of indicators they support.
- `templates/indicator_catalog.json`: the small set of high-impact indicators Raven should prioritize first.
- `templates/country_indicator_records.template.json`: a record template; intentionally contains no invented country statistics.
- `scripts/export_existing_registry.py`: exports Raven's existing `COUNTRIES_WORLD` into JSON without silently changing existing values.
- `scripts/validate_metadata.py`: checks metadata shape, probability sums, value ranges, source IDs and duplicate records.

## Important design rule

The existing `geography_world.py` already contains broad country context. Some values (e.g. industry/platform/payment/food lists and numeric `income`, `digital`, `cost`, `income_cv`, `urban_share`) may be legacy heuristics rather than verified statistical estimates. The export script preserves them but marks them `legacy_unverified`; it does not claim they are calibrated.

Do not replace current generation inputs until the exported metadata is compared with the code's expected shape and the tests pass. Use Firecrawl during development only to gather evidence, then review and validate candidate data before committing it. Production profile generation should read the committed metadata snapshot and must not call Firecrawl.

## Suggested rollout

1. Run the export script against the repository's existing `geography_world.py`.
2. Review current values and field mappings.
3. Use Firecrawl/OpenCode to collect evidence for priority indicators, preserving source URL, source ID, reference year, units and retrieval date.
4. Validate the candidates and explicitly approve the ones that are supported by evidence.
5. Integrate the validated file behind the existing geography service, retaining backward-compatible fields.
6. Run regression and statistical tests before deployment.

## Export command

From the Raven repository root:

```bash
python scripts/export_existing_registry.py path/to/geography_world.py --output data/metadata/country_registry_legacy.json
```

The script loads the file and serializes the existing dictionary. The exact path to the current module depends on Raven's repository layout.

## Validate command

```bash
python scripts/validate_metadata.py data/metadata/country_indicator_records.json --sources sources/source_registry.json
```

An empty or template-only records file is expected to report that no country statistics have been calibrated; it should not be treated as a validation failure for the legacy registry export.
