#!/usr/bin/env python3
"""Export Raven's existing COUNTRIES_WORLD dictionary to JSON without changing it."""
import argparse
import importlib.util
import json
from pathlib import Path


def load_registry(module_path: Path):
    spec = importlib.util.spec_from_file_location("raven_geography_world", module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load Python module: {module_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if not hasattr(module, "COUNTRIES_WORLD"):
        raise RuntimeError("Expected COUNTRIES_WORLD dictionary was not found")
    return module.COUNTRIES_WORLD


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("module_path", help="Path to Raven's existing geography_world.py")
    parser.add_argument("--output", default="country_registry_legacy.json")
    args = parser.parse_args()

    registry = load_registry(Path(args.module_path))
    out = {}
    for name, raw in sorted(registry.items()):
        item = {}
        for key, value in raw.items():
            item[key] = list(value) if isinstance(value, tuple) else value
        item["metadata_provenance"] = {
            "status": "legacy_unverified",
            "note": "Copied from the existing Raven registry; not independently calibrated by this export script."
        }
        out[name] = item

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps({"schema_version": "1.0", "countries": out}, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Exported {len(out)} country records to {output_path}")
    print("Note: existing values are preserved and marked legacy_unverified; review before changing production inputs.")


if __name__ == "__main__":
    main()
