#!/usr/bin/env python3
"""Validate Raven country indicator records without inventing or repairing data."""
import argparse
import json
import math
import sys
from pathlib import Path

VALID_STATUS = {"verified", "evidence_backed", "partial", "inferred", "legacy_unverified", "uncalibrated"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("records", help="JSON file with {schema_version, records: [...]}")
    parser.add_argument("--sources", help="Optional source_registry.json")
    args = parser.parse_args()
    payload = json.loads(Path(args.records).read_text(encoding="utf-8"))
    records = payload.get("records", [])
    source_ids = set()
    if args.sources:
        sources = json.loads(Path(args.sources).read_text(encoding="utf-8"))
        source_ids = {x["source_id"] for x in sources.get("sources", [])}

    errors, warnings, seen = [], [], set()
    for i, r in enumerate(records):
        prefix = f"records[{i}]"
        code = r.get("country_code")
        indicator = r.get("indicator_id")
        if not isinstance(code, str) or len(code) != 2 or not code.isupper():
            errors.append(f"{prefix}: country_code must be an uppercase two-letter code")
        if not indicator:
            errors.append(f"{prefix}: missing indicator_id")
        key = (code, indicator)
        if key in seen:
            errors.append(f"{prefix}: duplicate country_code + indicator_id {key}")
        seen.add(key)
        status = r.get("evidence_status")
        if status not in VALID_STATUS:
            errors.append(f"{prefix}: invalid evidence_status {status!r}")
        if r.get("approved_for_generation") and status not in {"verified", "evidence_backed"}:
            errors.append(f"{prefix}: only verified/evidence_backed records can be approved for generation")
        if r.get("approved_for_generation") and not r.get("source_ids"):
            errors.append(f"{prefix}: approved record has no source_ids")
        if source_ids:
            for sid in r.get("source_ids", []):
                if sid not in source_ids:
                    errors.append(f"{prefix}: unknown source_id {sid!r}")
        distribution = r.get("distribution")
        if distribution is not None:
            probs = distribution.get("probabilities", {})
            vals = list(probs.values())
            if not vals:
                errors.append(f"{prefix}: distribution probabilities are empty")
            elif any(not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0 or v > 1 for v in vals):
                errors.append(f"{prefix}: probabilities must be finite numbers in [0, 1]")
            elif abs(sum(vals) - 1.0) > 1e-6:
                errors.append(f"{prefix}: probabilities sum to {sum(vals):.8f}, expected 1.0")
        if status in {"uncalibrated", "legacy_unverified", "inferred"}:
            warnings.append(f"{prefix}: evidence status is {status}; do not present as calibrated country evidence")
        if not r.get("source_ids") and status in {"verified", "evidence_backed", "partial"}:
            errors.append(f"{prefix}: evidence-backed record needs source_ids")

    print(f"Records: {len(records)} | Errors: {len(errors)} | Warnings: {len(warnings)}")
    for e in errors:
        print("ERROR:", e)
    for w in warnings:
        print("WARNING:", w)
    if errors:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
